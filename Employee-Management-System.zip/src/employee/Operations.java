import java.sql.*;

public class Operations {
    public void addEmployee(Employee emp) {
        // Logic to insert employee in DB using JDBC
    }
}