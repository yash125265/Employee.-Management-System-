import javax.swing.*;

public class Windows {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Employee Management System");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}