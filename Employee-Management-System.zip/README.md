# Employee Management System

A simple Java Swing + JDBC based desktop application to manage employee records.